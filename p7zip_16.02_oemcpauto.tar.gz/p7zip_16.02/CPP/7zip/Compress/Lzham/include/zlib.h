#define LZHAM_DEFINE_ZLIB_API
#include "lzham.h"
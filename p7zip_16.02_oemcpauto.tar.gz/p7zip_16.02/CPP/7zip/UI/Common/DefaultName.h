// DefaultName.h

#ifndef __DEFAULT_NAME_H
#define __DEFAULT_NAME_H

#include "../../../Common/MyString.h"

UString GetDefaultName2(const UString &fileName,
    const UString &extension, const UString &addSubExtension);

#endif
